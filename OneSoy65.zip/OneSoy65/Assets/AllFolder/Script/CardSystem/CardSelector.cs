using UnityEngine;

public class CardSelector : MonoBehaviour
{
    private Camera mainCamera;

    void Start()
    {
        mainCamera = Camera.main;
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Vector2 mousePos = mainCamera.ScreenToWorldPoint(Input.mousePosition);
            RaycastHit2D[] hits = Physics2D.RaycastAll(mousePos, Vector2.zero);

            if (hits.Length > 0)
            {
                GameObject topCard = null;
                int topSortingOrder = int.MinValue;

                foreach (RaycastHit2D hit in hits)
                {
                    SpriteRenderer sr = hit.collider.GetComponent<SpriteRenderer>();
                    if (sr != null && sr.sortingOrder > topSortingOrder)
                    {
                        topSortingOrder = sr.sortingOrder;
                        topCard = hit.collider.gameObject;
                    }
                }

                if (topCard != null)
                {
                    topCard.GetComponent<DraggableCard>().StartDragging();
                }
            }
        }
        else if (Input.GetMouseButtonUp(0))
        {
            DraggableCard.StopAllDragging();
        }
    }
}
