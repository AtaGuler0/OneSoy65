using UnityEngine;

public class TriggerReveal : MonoBehaviour
{
    public GameObject[] objectsToReveal; // Görünür hale getirilecek objeler

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player")) // Oyuncuya temas ettiğinde
        {
            foreach (GameObject obj in objectsToReveal)
            {
                obj.SetActive(true); // Obje görünür hale gelir
            }
        }
    }
}
