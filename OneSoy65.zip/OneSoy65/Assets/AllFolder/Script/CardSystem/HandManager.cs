using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Splines;
using DG.Tweening; // DOTween animasyonları için.

public class HandManager : MonoBehaviour
{
    [SerializeField] private int maxHandSize; // Maksimum kart sayısı.
    [SerializeField] private GameObject cardPrefab; // Kart prefabı.
    [SerializeField] private SplineContainer splineContainer; // Kartların sıralanacağı spline yolu.
    [SerializeField] private Transform spawnPoint; // Kartların doğduğu nokta.

    private List<GameObject> handCards = new(); // Elde bulunan kartların listesi.
    private bool isSpread = false; // Kartların yayılmış olup olmadığını kontrol eder.
    
    private float defaultSpacing = 0.05f; // Kartlar başlangıçta yakın.
    private float spreadSpacing = 0.12f; // Space'e basınca açılma mesafesi.

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Return)) // Enter tuşuna basınca kart çeker.
        {
            DrawCard();
        }

        if (Input.GetKeyDown(KeyCode.Space)) // Space tuşuna basınca kartları açar/kapatır.
        {
            ToggleCardSpread();
        }
    }

    private void DrawCard()
    {
        if (handCards.Count >= maxHandSize) return; // Maksimum kart sayısına ulaşıldıysa ekleme.

        GameObject g = Instantiate(cardPrefab, spawnPoint.position, spawnPoint.rotation); // Yeni kart oluştur.
        handCards.Add(g); // Listeye ekle.
        UpdateCardPositions(); // Kart pozisyonlarını güncelle.

        SpriteRenderer sr = g.GetComponent<SpriteRenderer>();
        if (sr != null)
        {
        sr.sortingOrder = handCards.Count;
        }

    }

    private void ToggleCardSpread()
    {
        isSpread = !isSpread; // Açma/Kapama durumu tersine çevir.
        UpdateCardPositions(); // Kart konumlarını güncelle.
    }

    private void UpdateCardPositions()
    {
        if (handCards.Count == 0) return; // Eğer elde kart yoksa işlem yapma.

        float cardSpacing = isSpread ? spreadSpacing : defaultSpacing;
        // Eğer kartlar yayılmışsa (isSpread == true), geniş aralıklı olsun.
        // Eğer kapalıysa (isSpread == false), başlangıçtaki gibi yakın olsun.

        float firstCardPosition = 0.5f - (handCards.Count - 1) * cardSpacing / 2;
        // İlk kartın spline üzerindeki konumunu hesapla.

        Spline spline = splineContainer.Spline; // Spline'ı referans al.

        for (int i = 0; i < handCards.Count; i++)
        {
            float p = firstCardPosition + i * cardSpacing; // Her kart için spline üzerindeki pozisyonu hesapla.
            Vector3 splinePosition = spline.EvaluatePosition(p); // Belirlenen spline üzerindeki pozisyonu al.

            handCards[i].transform.DOMove(splinePosition, 0.25f); // Kartları smooth şekilde hareket ettir.
            handCards[i].transform.DOLocalRotate(Vector3.zero, 0.25f); // Kartların düz durmasını sağla.
        }
        // ...

        for (int i = 0; i < handCards.Count; i++)
        {
            float p = firstCardPosition + i * cardSpacing;
            Vector3 splinePosition = spline.EvaluatePosition(p);

            handCards[i].transform.DOMove(splinePosition, 0.25f);
            handCards[i].transform.DOLocalRotate(Vector3.zero, 0.25f);

             // ✨ En önemli satır: sorting order ver.
            SpriteRenderer sr = handCards[i].GetComponent<SpriteRenderer>();
            if (sr != null)
            {
            sr.sortingOrder = i; // Veya handCards.Count - i (tersten sıralamak için)
            }
        }

    }
}
