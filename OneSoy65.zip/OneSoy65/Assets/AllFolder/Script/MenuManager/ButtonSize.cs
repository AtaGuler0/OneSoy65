using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;  // EventSystems kütüphanesini eklemelisiniz.
using DG.Tweening;

public class ButtonSize : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    private Vector3 originalScale;

    void Start()
    {
        // Butonun başlangıç boyutunu kaydediyoruz.
        originalScale = transform.localScale;
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        // Mouse kartın üzerine geldiğinde kartı biraz büyütüyoruz.
        transform.DOScale(originalScale * 1.1f, 0.15f);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        // Mouse kartın üzerinden ayrıldığında eski boyutuna döndürüyoruz.
        transform.DOScale(originalScale, 0.15f);
    }
}
