using UnityEngine;
using UnityEngine.UI;

public class SettingsMenu : MonoBehaviour
{
    public GameObject settingsPanel; // Ayarlar menüsü paneli
    public Button settingsButton; // Ayarlar butonu
    public Button closeButton; // Kapatma butonu

    void Start()
    {
        // Butonlara tıklama olaylarını bağla
        if (settingsButton != null)
        {
            settingsButton.onClick.AddListener(ToggleSettings);
        }

        if (closeButton != null)
        {
            closeButton.onClick.AddListener(CloseMenu);
        }

        // Oyuna başlarken menüyü kapalı yap
        settingsPanel.SetActive(false);
    }

    void Update()
    {
        // ESC tuşuna basıldığında menüyü aç/kapat
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            ToggleSettings();
        }
    }

    public void ToggleSettings()
    {
        // Menünün açık olup olmadığını kontrol edip tersine çeviriyoruz
        settingsPanel.SetActive(!settingsPanel.activeSelf);
    }

    public void CloseMenu()
    {
        // Ayarlar menüsünü kapat
        settingsPanel.SetActive(false);
    }
}
