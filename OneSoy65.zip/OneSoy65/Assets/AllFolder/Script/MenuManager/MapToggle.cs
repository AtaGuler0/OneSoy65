using UnityEngine;
using UnityEngine.UI;

public class MapController : MonoBehaviour
{
    public GameObject mapPanel;   // Harita paneli
    public Button openMapButton;  // Açma butonu
    public Button closeMapButton; // Kapatma butonu

    void Start()
    {
        // Başlangıçta haritayı kapat ve sadece açma butonunu göster
        mapPanel.SetActive(false);
        closeMapButton.gameObject.SetActive(false);

        // Butonlara işlev ekle
        openMapButton.onClick.AddListener(OpenMap);
        closeMapButton.onClick.AddListener(CloseMap);
    }

    public void OpenMap()
    {
        mapPanel.SetActive(true);  // Harita aç
        openMapButton.gameObject.SetActive(false);  // Açma butonunu gizle
        closeMapButton.gameObject.SetActive(true);  // Kapatma butonunu göster
    }

    public void CloseMap()
    {
        mapPanel.SetActive(false);  // Harita kapat
        openMapButton.gameObject.SetActive(true);   // Açma butonunu geri getir
        closeMapButton.gameObject.SetActive(false); // Kapatma butonunu gizle
    }
}
