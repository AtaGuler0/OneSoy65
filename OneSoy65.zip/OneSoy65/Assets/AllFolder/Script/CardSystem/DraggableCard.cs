using UnityEngine;
using DG.Tweening;

public class DraggableCard : MonoBehaviour
{
    private Vector3 offset;
    private static Camera mainCamera;
    private Vector3 originalScale;
    private Vector3 dragStartPosition;

    private bool isDragging = false;
    private static DraggableCard currentlyDragging;

    void Start()
    {
        if (mainCamera == null)
            mainCamera = Camera.main;

        originalScale = transform.localScale;
    }

    void Update()
    {
        if (isDragging)
        {
            transform.position = GetMouseWorldPosition() + offset;
        }
    }

    public void StartDragging()
    {
        if (currentlyDragging != null) return;

        currentlyDragging = this;
        isDragging = true;
        offset = transform.position - GetMouseWorldPosition();
        dragStartPosition = transform.position;
        transform.DOScale(originalScale * 1.1f, 0.1f);
    }

    public static void StopAllDragging()
    {
        if (currentlyDragging != null)
        {
            currentlyDragging.StopDragging();
            currentlyDragging = null;
        }
    }

    private void StopDragging()
    {
        isDragging = false;
        transform.DOScale(originalScale, 0.15f);
        transform.DOMove(dragStartPosition, 0.15f);
    }

    private Vector3 GetMouseWorldPosition()
    {
        Vector3 mousePoint = Input.mousePosition;
        mousePoint.z = 0f;
        return mainCamera.ScreenToWorldPoint(mousePoint);
    }

    void OnMouseEnter()
    {
        if (!isDragging)
            transform.DOScale(originalScale * 1.1f, 0.15f);
    }

    void OnMouseExit()
    {
        if (!isDragging)
            transform.DOScale(originalScale, 0.15f);
    }
}
